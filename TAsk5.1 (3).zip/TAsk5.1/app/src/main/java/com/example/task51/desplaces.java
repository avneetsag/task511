package com.example.task51;

public class desplaces {
    private int desimage;
    private String desdescription;
    private String destitle;

    public desplaces(String destitle, String desdescription ,int desimage) {
        this.desimage = desimage;
        this.desdescription = desdescription;
        this.destitle = destitle;
    }

    public int getDesimage() {
        return desimage;
    }

    public void setDesimage(int desimage) {
        this.desimage = desimage;
    }

    public String getDesdescription() {
        return desdescription;
    }

    public void setDesdescription(String desdescription) {
        this.desdescription = desdescription;
    }

    public String getDestitle() {
        return destitle;
    }

    public void setDestitle(String destitle) {
        this.destitle = destitle;
    }
}
