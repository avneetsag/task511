package com.example.task51;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class
MainActivity extends AppCompatActivity {

    RecyclerView recycler, recycler2;
    RecyclerViewAdapter recyclerViewAdapter;
    RecyclerViewAdapterNew recyclerViewAdapter1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recycler = findViewById(R.id.recycler);
        recycler2 = findViewById(R.id.recycler2);

        desplaces[] desplace_data = new desplaces[]{
                new desplaces("Paris", "Paris (French pronunciation: \u200B[paʁi] (About this soundlisten)) is the capital and most populous city of France, with an estimated population of 2,175,601 residents as of 2018, in an area of more than 105 square kilometres (41 square miles).", R.drawable.paris),
                new desplaces("Bora_Bora", "Bora Bora (French: Bora-Bora; Tahitian: Pora Pora) is an island group in the Leeward Islands.", R.drawable.bora_bora),
                new desplaces("Glacier National Park", "Glacier National Park is an American national park located in northwestern Montana, on the Canada–United States border, adjacent to the Canadian provinces of Alberta and British Columbia", R.drawable.glacier_national_park),
                new desplaces("Maui", "he big tourist spots in Maui include the Hāna Highway, Haleakalā National Park, Iao Valley, and Lahaina", R.drawable.maui),
                new desplaces("South Island", "The South Island, also officially named Te Waipounamu,[1] is the larger of the two major islands of New Zealand in surface area, the other being the smaller but more populous North Island.", R.drawable.south_island),
        };
        
        Titplaces[] titplace_data  = new Titplaces[]
                {
                        new Titplaces("Paris",R.drawable.paris),
                        new Titplaces("Bora_Bora", R.drawable.bora_bora),
                        new Titplaces("Glacier National Park", R.drawable.glacier_national_park),
                        new Titplaces("Maui", R.drawable.maui),
                        new Titplaces("South Island", R.drawable.south_island),
                };

        recycler2.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false));
        recycler.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));
        recyclerViewAdapter = new RecyclerViewAdapter(desplace_data, MainActivity.this);
        recyclerViewAdapter1 = new RecyclerViewAdapterNew(titplace_data, MainActivity.this);
        recycler2.setAdapter(recyclerViewAdapter);
        recycler.setAdapter(recyclerViewAdapter1);

    }
}