package com.example.task51;

public class Titplaces {
    private String tittitle;
    private int titimage;

    public Titplaces(String tittitle, int titimage) {
        this.tittitle = tittitle;
        this.titimage = titimage;
    }

    public String getTittitle() {
        return tittitle;
    }

    public void setTittitle(String tittitle) {
        this.tittitle = tittitle;
    }

    public int getTitimage() {
        return titimage;
    }

    public void setTitimage(int titimage) {
        this.titimage = titimage;
    }
}
