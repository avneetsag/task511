package com.example.task51;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

public class RecyclerViewAdapterNew extends RecyclerView.Adapter<RecyclerViewAdapterNew.ViewHolder>
{
    Titplaces[] listplacesnew;
    Context context;


    public RecyclerViewAdapterNew(Titplaces[] listplacesnew, MainActivity activity) {
        this.listplacesnew = listplacesnew;
        this.context = activity;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.places2,parent,false);
        ViewHolder viewHolder1 = new ViewHolder(view);
        return viewHolder1;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position)
    {
        final Titplaces placeList_data_new  = listplacesnew[position];

        holder.Title2.setText(placeList_data_new.getTittitle());
        holder.imageView2.setImageResource(placeList_data_new.getTitimage());

        holder.itemView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if(placeList_data_new.getTittitle() == "Paris")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    paris parisFragment = new paris();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.contraint, parisFragment).addToBackStack(null).commit();
                }
                else if(placeList_data_new.getTittitle() == "Bora Bora")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    bora_bora boraFragment = new bora_bora();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.contraint, boraFragment).addToBackStack(null).commit();

                }

                else if(placeList_data_new.getTittitle() == "Glacier National Park")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    glacier_national_park glacierFragment = new glacier_national_park();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.contraint,glacierFragment).addToBackStack(null).commit();

                }

                else if(placeList_data_new.getTittitle() == "Maui")
                {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    maui mauiFragment = new maui();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.contraint, mauiFragment).addToBackStack(null).commit();

                }

                else if(placeList_data_new.getTittitle() == "South Island") {
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    south_island southFragment = new south_island();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.contraint, southFragment).addToBackStack(null).commit();
                }

                else
                {
                    Toast.makeText(context,placeList_data_new.getTittitle(), Toast.LENGTH_SHORT).show();
                }

            }
        });
    }


    @Override
    public int getItemCount() {
        return listplacesnew.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView Title2;
        ImageView imageView2;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            Title2 = itemView.findViewById(R.id.Title2);
            imageView2 = itemView.findViewById(R.id.imageView2);
        }
    }
}

